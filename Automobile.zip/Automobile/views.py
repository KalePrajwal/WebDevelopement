from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from .models import *
import json

def index(request):
    return render(request,'index.html')

def admin(request):
    return render(request,'admin.html')

def signIn(request):
    mess = None
    if request.method == "GET":
        try:
            data = request.GET['data']
            dic = json.loads(data)
            id = dic['id']
            psw = dic['psw']
            obj = user()
            mess = obj.signIn(id, psw)
        except: mess = None
    return HttpResponse(mess)

def register(request):
    mess = None
    if request.method == "GET":
        try:
            data = request.GET['data']
            dic = json.loads(data)
            id = dic['id']
            em = dic['email']
            psw = dic['psw']
            obj = user()
            mess = obj.register(id, em, psw)
        except: mess = None
    return HttpResponse(mess)

def searchCar(request):
    result = None
    if request.method == "GET":
        try:
            data = request.GET['data']
            dic = json.loads(data)
            ty = dic['type']
            nm = dic['name']
            obj = car()
            result = obj.searchCar(ty, nm)
        except: result = None
    return JsonResponse({'result': result})

def newCar(request):
    mess = None
    if request.method == "GET":
        try:
            data = request.GET['data']
            dic = json.loads(data)
            mod = dic['mod']
            comp = dic['comp']
            typ = dic['typ']
            eng = dic['eng']
            ful = dic['ful']
            pho = dic['pho']
            pri = dic['pri']
            obj = car()
            mess = obj.newCar(mod, comp, typ, eng, ful, pho, pri)
        except: mess = None
    return HttpResponse(mess)

def editCar(request):
    mess = None
    if request.method == "GET":
        try:
            data = request.GET['data']
            dic = json.loads(data)
            mod = dic['mod']
            pri = dic['pri']
            obj = car()
            mess = obj.editCar(mod, pri)
        except: mess = None
    return HttpResponse(mess)

def searchCust(request):
    result = None
    if request.method == "GET":
        try:
            data = request.GET['data']
            dic = json.loads(data)
            ty = dic['type']
            nm = dic['name']
            obj = customer()
            result = obj.searchCust(ty, nm)
        except: result = None
    return JsonResponse({'result': result})

def newCust(request):
    mess = None
    if request.method == "GET":
        try:
            data = request.GET['data']
            dic = json.loads(data)
            id = dic['id']
            nm = dic['nm']
            mo = dic['mob']
            add = dic['add']
            obj = customer()
            mess = obj.newCust(id, nm, mo, add)
        except: mess = None
    return HttpResponse(mess)

def editCust(request):
    mess = None
    if request.method == "GET":
        try:
            data = request.GET['data']
            dic = json.loads(data)
            id = dic['id']
            mo = dic['mob']
            obj = customer()
            mess = obj.editCust(id, mo)
        except: mess = None
    return HttpResponse(mess)