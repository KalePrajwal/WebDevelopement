import pymysql as my

class user():
    def signIn(self, id, psw):
        mess = None
        try:
            con = my.connect(host='bftwbvcwphfzfc96rmt8-mysql.services.clever-cloud.com', user='ubm6bcwfk0wgghj5', password='dkLqATSTs4TQ9ryVgopW', database='bftwbvcwphfzfc96rmt8')
            curs = con.cursor()
            curs.execute("select * from users where id = '%s'" %id)
            data = curs.fetchall()
            if data:
                if data[0][2] == psw:
                    mess = 'Yes'
                else:
                    mess = 'No'
            else:
                mess = 'No'
            con.close()
        except: mess = None
        return mess

    def register(self, id, em, psw):
        mess = None
        try:
            con = my.connect(host='bftwbvcwphfzfc96rmt8-mysql.services.clever-cloud.com', user='ubm6bcwfk0wgghj5', password='dkLqATSTs4TQ9ryVgopW', database='bftwbvcwphfzfc96rmt8')
            curs = con.cursor()
            if len(id) > 4 and len(psw) >= 8:
                curs.execute("select * from users where id = '%s'" %id)
                data = curs.fetchall()
                if data:
                    mess = 'No'
                else:
                    curs.execute("insert into users values('%s', '%s', '%s')" %(id, em, psw))
                    con.commit()
                    mess = 'Yes'
            else:
                mess = 'No'
            con.close()
        except: mess = None
        return mess


class car():
    def searchCar(self, ty, nm):
        result = None
        try:
            con = my.connect(host='bftwbvcwphfzfc96rmt8-mysql.services.clever-cloud.com', user='ubm6bcwfk0wgghj5', password='dkLqATSTs4TQ9ryVgopW', database='bftwbvcwphfzfc96rmt8')
            curs = con.cursor()
            if ty.upper() == 'MODEL': curs.execute("select * from cars where model = '%s'" %nm)
            elif ty.upper() == 'TYPE': curs.execute("select * from cars where type = '%s'" %nm)
            elif ty.upper() == 'COMPANY': curs.execute("select * from cars where company = '%s'" %nm)
            elif ty.upper() == 'ALL': curs.execute("select * from cars")

            data = curs.fetchall()
            if data:
                result = {}
                i = 0
                for rec in data:
                    result[i] = {}
                    result[i]['mod'] = rec[0]
                    result[i]['comp'] = rec[1]
                    result[i]['typ'] = rec[2]
                    result[i]['eng'] = rec[3]
                    result[i]['ful'] = rec[4]
                    result[i]['pho'] = rec[5]
                    result[i]['pri'] = rec[6]
                    i += 1
            else: result = 'Empty'
            con.close()
        except: result = None
        return result
    
    def newCar(self, mod, comp, typ, eng, ful, pho, pri):
        mess = None
        try:
            con = my.connect(host='bftwbvcwphfzfc96rmt8-mysql.services.clever-cloud.com', user='ubm6bcwfk0wgghj5', password='dkLqATSTs4TQ9ryVgopW', database='bftwbvcwphfzfc96rmt8')
            curs = con.cursor()
            curs.execute("select * from cars where model = '%s'" %mod)
            data = curs.fetchall()
            if data: mess = "No"
            else:
                curs.execute("insert into cars values('%s', '%s', '%s', '%s', '%s', '%s', '%s')" %(mod, comp, typ, eng, ful, pho, pri))
                con.commit()
                mess = 'Yes'
            con.close()
        except: mess = None
        return mess
    
    def editCar(self, mod, pri):
        mess = None
        try:
            con = my.connect(host='bftwbvcwphfzfc96rmt8-mysql.services.clever-cloud.com', user='ubm6bcwfk0wgghj5', password='dkLqATSTs4TQ9ryVgopW', database='bftwbvcwphfzfc96rmt8')
            curs = con.cursor()
            curs.execute("select * from cars where model = '%s'" %mod)
            data = curs.fetchall()
            if data:
                curs.execute("update cars set price = '%s' where model = '%s'" %(pri, mod))
                con.commit()
                mess = 'Yes'
            else: mess = 'No'
            con.close()
        except: mess = None
        return mess
    
class customer():
    def searchCust(self, ty, nm):
        result = None
        try:
            con = my.connect(host='bftwbvcwphfzfc96rmt8-mysql.services.clever-cloud.com', user='ubm6bcwfk0wgghj5', password='dkLqATSTs4TQ9ryVgopW', database='bftwbvcwphfzfc96rmt8')
            curs = con.cursor()
            if ty.upper() == 'ID': curs.execute("select * from customers where id = '%s'" %nm)
            elif ty.upper() == 'ALL': curs.execute("select * from customers")
            
            data = curs.fetchall()
            if data:
                result = {}
                i = 0
                for rec in data:
                    result[i] = {}
                    result[i]['id'] = rec[0]
                    result[i]['nm'] = rec[1]
                    result[i]['mob'] = rec[2]
                    result[i]['add'] = rec[3]
                    i += 1
            else: result = 'Empty'
            con.close()
        except: result = None
        return result
    
    def newCust(self, id, nm, mo, ad):
        mess = None
        try:
            con = my.connect(host='bftwbvcwphfzfc96rmt8-mysql.services.clever-cloud.com', user='ubm6bcwfk0wgghj5', password='dkLqATSTs4TQ9ryVgopW', database='bftwbvcwphfzfc96rmt8')
            curs = con.cursor()
            curs.execute("select * from customers where id = '%s'" %id)
            data = curs.fetchall()
            if data:
                mess = 'No'
            else:
                curs.execute("insert into customers values('%s', '%s', '%s', '%s')" %(id, nm, mo, ad))
                con.commit()
                mess = 'Yes'
            con.close()
        except: mess = None
        return mess
    
    def editCust(self, id, mo):
        mess = None
        try:
            con = my.connect(host='bftwbvcwphfzfc96rmt8-mysql.services.clever-cloud.com', user='ubm6bcwfk0wgghj5', password='dkLqATSTs4TQ9ryVgopW', database='bftwbvcwphfzfc96rmt8')
            curs = con.cursor()
            curs.execute("select * from customers where id = '%s'" %id)
            data = curs.fetchall()
            if data:
                curs.execute("update customers set mobile = '%s' where id = '%s'" %(mo, id))
                con.commit()
                mess = 'Yes'
            else: mess = 'No'
            con.close()
        except: mess = None
        return mess