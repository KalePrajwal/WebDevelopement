function createRequestObject() {
    var xmlHTTPObject;
    if (window.XMLHttpRequest) {
        xmlHTTPObject = new XMLHttpRequest();
    }
    else if (window.ActiveXObject) {
        xmlHTTPObject = new ActiveXObject("Microsoft.xmlHTTPObject");
    }
    return xmlHTTPObject;
}
var http = createRequestObject();

function home(){
    document.getElementById("home").style.display = "block";
    document.getElementById("cars").style.display = "none";
}

function cars(){
    document.getElementById("home").style.display = "none";
    document.getElementById("cars").style.display = "block";
}

function signIn(){
    id = document.getElementById("snid").value;
    psw = document.getElementById("snpsw").value;
    http.open("get", "/signin/?data=" + JSON.stringify({"id":id,"psw":psw}));
    http.onreadystatechange = signInResponse;
    http.send(null);
}

function signInResponse(){
    if(http.readyState == 4){
        result = http.responseText;
        if(result == "No"){
            document.getElementById("signin-mess").innerHTML = "Please check id and password"
        }
        else if(result == "Yes"){
            document.getElementById("signin").action = "/user/";
            document.getElementById("signin").submit();
        }
        else if(result == "None"){
            document.getElementById("signin-mess").innerHTML = "Error"
        }
    }
}

function register(){
    id = document.getElementById("rgid").value;
    email = document.getElementById("rgemail").value;
    psw = document.getElementById("rgpsw").value;
    http.open("get", "/register/?data=" + JSON.stringify({"id":id,"email":email,"psw":psw}));
    http.onreadystatechange = registerResponse;
    http.send(null);
}

function registerResponse(){
    if(http.readyState == 4){
        result = http.responseText;
        if(result == "No"){
            document.getElementById("regi-mess").innerHTML = "Registeration failed Please check id and password"
        }
        else if(result == "Yes"){
            document.getElementById("regi-mess").innerHTML = "You are registered successfully"
        }
        else if(result == "None"){
            document.getElementById("regi-mess").innerHTML = "Error"
        }
    }
}

function model(){
    mod = document.getElementById("mod").value;
    http.open("get", "/searchcar/?data=" + JSON.stringify({'type': 'Model', 'name': mod}));
    http.onreadystatechange = showCarResponse;
    http.send(null);
}

function allCars(){
    http.open("get", "/searchcar/?data=" + JSON.stringify({'type': 'All', 'name': 'All'}));
    http.onreadystatechange = showCarResponse;
    http.send(null);
}

function company(comp){
    http.open("get", "/searchcar/?data=" + JSON.stringify({'type': 'Company', 'name': comp}));
    http.onreadystatechange = showCarResponse;
    http.send(null);
}

function type(typ){
    http.open("get", "/searchcar/?data=" + JSON.stringify({'type': 'Type', 'name': typ}));
    http.onreadystatechange = showCarResponse;
    http.send(null);
}

function showCarResponse(){
    if(http.readyState == 4){
        result = JSON.parse(http.responseText);
        document.getElementById("car-mess").style.display = "block";
        if(result.result == "Empty"){
            document.getElementById("car-mess").innerHTML = "Sorry! no cars in our Showroom";
        }
        else if(result.result == null){
            document.getElementById("car-mess").innerHTML = "Error";
        }
        else{
            document.getElementById("car-mess").style.display = "none";
            showCars(result);
        }
    }
}

function showCars(val){
    document.getElementById("car-1").style.display = "none";
    document.getElementById("car-2").style.display = "none";
    if(val == "inc"){
        car += 1;
    }
    else if(val == "dec"){
        car -= 1;
    }
    else{
        result = val;
        car = 0;
    }
    
    document.getElementById("img-1").src = result.result[car].pho;
    document.getElementById("mod-1").innerHTML  = "Model : " + result.result[car].mod;
    document.getElementById("comp-1").innerHTML = "Company : " + result.result[car].comp;
    document.getElementById("typ-1").innerHTML  = "Type : " + result.result[car].typ;
    document.getElementById("eng-1").innerHTML  = "Engine : " + result.result[car].eng;
    document.getElementById("ful-1").innerHTML  = "Fuel: " + result.result[car].ful;
    document.getElementById("pri-1").innerHTML  = "Price : " + result.result[car].pri;
    document.getElementById("car-1").style.display = "block";

    if(val == "dec"){
        car -= 1;
    }
    else{
        car += 1;
    }
    document.getElementById("img-2").src = result.result[car].pho;
    document.getElementById("mod-2").innerHTML  = "Model : " + result.result[car].mod;
    document.getElementById("comp-2").innerHTML = "Company : " + result.result[car].comp;
    document.getElementById("typ-2").innerHTML  = "Type : " + result.result[car].typ;
    document.getElementById("eng-2").innerHTML  = "Engine : " + result.result[car].eng;
    document.getElementById("ful-2").innerHTML  = "Fuel: " + result.result[car].ful;
    document.getElementById("pri-2").innerHTML  = "Price : " + result.result[car].pri;
    document.getElementById("car-2").style.display = "block";
}