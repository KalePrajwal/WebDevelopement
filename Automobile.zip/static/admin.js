function createRequestObject() {
    var xmlHTTPObject;
    if (window.XMLHttpRequest) {
        xmlHTTPObject = new XMLHttpRequest();
    }
    else if (window.ActiveXObject) {
        xmlHTTPObject = new ActiveXObject("Microsoft.xmlHTTPObject");
    }
    return xmlHTTPObject;
}
var http = createRequestObject();

function home(){
    document.getElementById("home").style.display = "block";
    document.getElementById("cars").style.display = "none";
    document.getElementById("editcars").style.display = "none";
    document.getElementById("customer").style.display = "none";
    document.getElementById("editcust").style.display = "none";
}
function cars(){
    document.getElementById("home").style.display = "none";
    document.getElementById("cars").style.display = "block";
    document.getElementById("editcars").style.display = "none";
    document.getElementById("customer").style.display = "none";
    document.getElementById("editcust").style.display = "none";
}
function editCars(){
    document.getElementById("home").style.display = "none";
    document.getElementById("cars").style.display = "none";
    document.getElementById("editcars").style.display = "block";
    document.getElementById("customer").style.display = "none";
    document.getElementById("editcust").style.display = "none";
}
function customer(){
    document.getElementById("home").style.display = "none";
    document.getElementById("cars").style.display = "none";
    document.getElementById("editcars").style.display = "none";
    document.getElementById("customer").style.display = "block";
    document.getElementById("editcust").style.display = "none";
}
function editCustBlock(){
    document.getElementById("home").style.display = "none";
    document.getElementById("cars").style.display = "none";
    document.getElementById("editcars").style.display = "none";
    document.getElementById("customer").style.display = "none";
    document.getElementById("editcust").style.display = "block";
}

function model(){
    mod = document.getElementById("mod").value;
    http.open("get", "/searchcar/?data=" + JSON.stringify({'type': 'Model', 'name': mod}));
    http.onreadystatechange = showCarResponse;
    http.send(null);
}
function allCars(){
    http.open("get", "/searchcar/?data=" + JSON.stringify({'type': 'All', 'name': 'All'}));
    http.onreadystatechange = showCarResponse;
    http.send(null);
}
function company(comp){
    http.open("get", "/searchcar/?data=" + JSON.stringify({'type': 'Company', 'name': comp}));
    http.onreadystatechange = showCarResponse;
    http.send(null);
}
function type(typ){
    http.open("get", "/searchcar/?data=" + JSON.stringify({'type': 'Type', 'name': typ}));
    http.onreadystatechange = showCarResponse;
    http.send(null);
}
function showCarResponse(){
    if(http.readyState == 4){
        result = JSON.parse(http.responseText);
        document.getElementById("car-mess").style.display = "block";
        if(result.result == "Empty"){
            document.getElementById("car-mess").innerHTML = "Sorry! no cars in our Showroom";
        }
        else if(result.result == null){
            document.getElementById("car-mess").innerHTML = "Error";
        }
        else{
            document.getElementById("car-mess").style.display = "none";
            showCars(result);
        }
    }
}
function showCars(val){
    document.getElementById("car-1").style.display = "none";
    document.getElementById("car-2").style.display = "none";
    if(val == "inc"){
        car += 1;
    }
    else if(val == "dec"){
        car -= 1;
    }
    else{
        result = val;
        car = 0;
    }
    
    document.getElementById("img-1").src = result.result[car].pho;
    document.getElementById("mod-1").innerHTML  = "Model : " + result.result[car].mod;
    document.getElementById("comp-1").innerHTML = "Company : " + result.result[car].comp;
    document.getElementById("typ-1").innerHTML  = "Type : " + result.result[car].typ;
    document.getElementById("eng-1").innerHTML  = "Engine : " + result.result[car].eng;
    document.getElementById("ful-1").innerHTML  = "Fuel: " + result.result[car].ful;
    document.getElementById("pri-1").innerHTML  = "Price : " + result.result[car].pri;
    document.getElementById("car-1").style.display = "block";

    if(val == "dec"){
        car -= 1;
    }
    else{
        car += 1;
    }
    document.getElementById("img-2").src = result.result[car].pho;
    document.getElementById("mod-2").innerHTML  = "Model : " + result.result[car].mod;
    document.getElementById("comp-2").innerHTML = "Company : " + result.result[car].comp;
    document.getElementById("typ-2").innerHTML  = "Type : " + result.result[car].typ;
    document.getElementById("eng-2").innerHTML  = "Engine : " + result.result[car].eng;
    document.getElementById("ful-2").innerHTML  = "Fuel: " + result.result[car].ful;
    document.getElementById("pri-2").innerHTML  = "Price : " + result.result[car].pri;
    document.getElementById("car-2").style.display = "block";
}

function newCar(){
    mod = document.getElementById("nmod").value;
    comp = document.getElementById("ncom").value;
    typ = document.getElementById("ntyp").value;
    eng = document.getElementById("neng").value;
    fuel = document.getElementById("nful").value;
    pho = document.getElementById("npho").value;
    pri = document.getElementById("npri").value;

    http.open("get", "/newcar/?data=" + JSON.stringify({"mod": mod, "comp": comp, "typ": typ, "eng": eng,"ful": fuel, "pho": pho, "pri": pri}));
    http.onreadystatechange = newCarResponse;
    http.send(null);
}
function newCarResponse(){
    if(http.readyState == 4){
        result = http.responseText;
        document.getElementById("ncar-mess").style.display = "block";
        if(result == "No"){
            document.getElementById("ncar-mess").innerHTML = "Car Registration Failed";
        }
        else if(result == "Yes"){
            document.getElementById("ncar-mess").innerHTML = "Car Registered successfully";
        }
        else if(result == "None"){
            document.getElementById("ncar-mess").innerHTML = "Error";
        }
    }
}

function editCar(){
    mod = document.getElementById("emod").value;
    pri = document.getElementById("epri").value;

    http.open("get", "/editcar/?data=" + JSON.stringify({"mod": mod, "pri": pri}));
    http.onreadystatechange = editCarResponse;
    http.send(null);
}
function editCarResponse(){
    if(http.readyState == 4){
        result = http.responseText;
        document.getElementById("ecar-mess").style.display = "block";
        if(result == "No"){
            document.getElementById("ecar-mess").innerHTML = "Car Not found";
        }
        else if(result == "Yes"){
            document.getElementById("ecar-mess").innerHTML = "Price Change Successfully";
        }
        else if(result == "None"){
            document.getElementById("ecar-mess").innerHTML = "Error";
        }
    }
}

function custId(){
    id = document.getElementById("id").value;
    http.open("get", "/searchcust/?data=" + JSON.stringify({'type': 'id', 'name': id}));
    http.onreadystatechange = showCustResponse;
    http.send(null);
}
function allCust(){
    http.open("get", "/searchcust/?data=" + JSON.stringify({'type': 'All', 'name': 'All'}));
    http.onreadystatechange = showCustResponse;
    http.send(null);
}
function showCustResponse(){
    if(http.readyState == 4){
        result = JSON.parse(http.responseText);
        document.getElementById("cust-mess").style.display = "block";
        if(result.result == "Empty"){
            document.getElementById("cust-mess").innerHTML = "Sorry! No Customers";
        }
        else if(result.result == null){
            document.getElementById("cust-mess").innerHTML = "Error";
        }
        else{
            document.getElementById("cust-mess").style.display = "none";
            showCust(result);
        }
    }
}
function showCust(val){
    document.getElementById("cust-1").style.display = "none";
    document.getElementById("cust-2").style.display = "none";
    if(val == "inc"){
        cust += 1;
    }
    else if(val == "dec"){
        cust -= 1;
    }
    else{
        result = val;
        cust = 0;
    }
    
    document.getElementById("id-1").innerHTML  = "Id : " + result.result[cust].id;
    document.getElementById("nm-1").innerHTML = "Name : " + result.result[cust].nm;
    document.getElementById("mo-1").innerHTML  = "Mobile : " + result.result[cust].mob;
    document.getElementById("ad-1").innerHTML  = "Address : " + result.result[cust].add;
    document.getElementById("cust-1").style.display = "block";

    if(val == "dec"){
        cust -= 1;
    }
    else{
        cust += 1;
    }
    document.getElementById("id-2").innerHTML  = "Id : " + result.result[cust].id;
    document.getElementById("nm-2").innerHTML  = "Name : " + result.result[cust].nm;
    document.getElementById("mo-2").innerHTML  = "Mobile : " + result.result[cust].mob;
    document.getElementById("ad-2").innerHTML  = "Address : " + result.result[cust].add;
    document.getElementById("cust-2").style.display = "block";
}

function newCust(){
    event.preventDefault();
    id = document.getElementById("nid").value;
    nm = document.getElementById("nnm").value;
    mob = document.getElementById("nmo").value;
    add = document.getElementById("nad").value;

    http.open("get", "/newcust/?data=" + JSON.stringify({"id": id, "nm": nm, "mob": mob, "add": add}));
    http.onreadystatechange = newCustResponse;
    http.send(null);
}
function newCustResponse(){
    if(http.readyState == 4){
        result = http.responseText;
        document.getElementById("ncust-mess").style.display = "block";
        if(result == "No"){
            document.getElementById("ncust-mess").innerHTML = "Customer Registration Failed";
        }
        else if(result == "Yes"){
            document.getElementById("ncust-mess").innerHTML = "Customer Register successfully";
        }
        else if(result == "None"){
            document.getElementById("ncust-mess").innerHTML = "Error";
        }
    }
}

function editCust(){
    id = document.getElementById("eid").value;
    mo = document.getElementById("emo").value;

    http.open("get", "/editcust/?data=" + JSON.stringify({"id": id, "mob": mo}));
    http.onreadystatechange = editCarResponse;
    http.send(null);
}
function editCarResponse(){
    if(http.readyState == 4){
        result = http.responseText;
        document.getElementById("ecust-mess").style.display = "block";
        if(result == "No"){
            document.getElementById("ecust-mess").innerHTML = "Number Does Not Change";
        }
        else if(result == "Yes"){
            document.getElementById("ecust-mess").innerHTML = "Number change successfully";
        }
        else if(result == "None"){
            document.getElementById("ecust-mess").innerHTML = "Error";
        }
    }
}